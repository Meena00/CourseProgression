//no additional imports! 
import java.util.Collection;
import java.util.Queue;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
 
/**
* Priority queue represented as a balanced binary heap: the two
* children of queue[n] are queue[2*n+1] and queue[2*(n+1)].  The
* priority queue is ordered by the elements' natural ordering.
*/
public class MinHeap<E extends Comparable<E>> implements Queue<E> {
	//size of a queue when empty, should never shrink below this size
	private static final int DEFAULT_INITIAL_CAPACITY = 11;
	
	//you may not have any other instance variables, only these TWO
	//if you make more instance variables your MinHeap class will
	//receive a 0, no matter how well it works
	private Comparable<E>[] queue;

	private int size = 0;

	@SuppressWarnings("unchecked")
	public MinHeap() {
		//Initialize the queue here.
		
		//You cannot use the diamond syntax when creating an array, but you can cast to it. So you use this format:
		//ClassWithGeneric<T>[] items = (ClassWithGeneric<T>[]) new ClassWithGeneric[10];
	}

	public MinHeap(MinHeap<E> other) {
		//Initialize the queue here to be a copy of the other queue
	}
	
	//You will need additional methods defined in the Queue interface!
	
	//This is an iterator for the queue, complete it!
	public Iterator<E> iterator() {
		return new Iterator() {
			public boolean hasNext() {
				//replace this!
				return false;
			}
			
			@SuppressWarnings("unchecked")
			public E next() {
				//replace this!
				return null;
			}
		};
	}
}