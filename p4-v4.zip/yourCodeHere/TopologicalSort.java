import java.io.*;
import java.util.Scanner;

import java.util.Collection;
import java.util.LinkedList;
import java.util.HashSet;

class TopologicalSort {
	
	//this part works and is done for you
	public static ThreeTenGraph<String> getGraph(String filename) throws IOException {
		ThreeTenGraph<String> graph = new ThreeTenGraph<>();
		
		try(Scanner r = new Scanner(new File(filename))) {
			int numNodes = Integer.parseInt(r.nextLine());
			for(int i = 0; i < numNodes; i++) {
				String nodeName = r.nextLine().trim();
				graph.addVertex(nodeName);
			}
			
			int numEdges = Integer.parseInt(r.nextLine());
			for(int i = 0; i < numEdges; i++) {
				String[] fromToPriority = r.nextLine().trim().split(",");
				graph.addEdge(
					new Destination<String>(fromToPriority[1], Integer.parseInt(fromToPriority[2])),
					fromToPriority[0],
					fromToPriority[1]
				);
			}
		}
		
		return graph;
	}
	
	
	//uses DFS to create a topological sort
	//accepts a graph
	//throws IllegalArgumentException for invalid inputs for a topological sort
	public static <T extends Comparable<T>> LinkedList<T> topologicalSort(ThreeTenGraph<T> graph, T startNode) {
		//error checking on inputs, requires graph and a valid starting node
		
		if(graph == null || startNode == null) {
			throw new IllegalArgumentException("Graph does not contain starting node");
		}
		
		//YOUR CODE HERE: Add a check to make sure the start node is in the graph.
		//If not, throw the same exception as above.
		
		//YOUR CODE HERE: Create two empty HashSets, one called "started" and one called "finished"
		//these will help us track what we've already seen
		
		//YOUR CODE HERE: Create an empty linked list called "sortedOrder" use as our stack
		
		//initialize DFS
		boolean dfsDone = false;
		
		while(!dfsDone) {
			//visit the start node
			if(!visit(graph, startNode, started, finished, sortedOrder)) {
				//graph has no topological sorting
				throw new IllegalArgumentException("Graph contains a cycle.");
			}
			
			//make sure all the nodes have been visited
			dfsDone = true;
			for(T v : graph.getVertices()) {
				if(!finished.contains(v)) {
					startNode = v;
					dfsDone = false;
					break;
				}
			}
		}
		
		//return the topological sorting
		return sortedOrder;
	}
	
	//returns false if there was a cycle
	private static <T extends Comparable<T>> boolean visit(ThreeTenGraph<T> graph, T currentNode, HashSet<T> started, HashSet<T> finished, LinkedList<T> sortedOrder) {
		//YOUR CODE HERE: This node is "started" so add it to the started set
		
		//YOUR CODE HERE: get the neighbors of the current node in sorted order,
		//reverse them, and store them in a linked list called "revNeighbors"
		
		//visit each neighbor who hasn't been visited before
		for(T neighbor : revNeighbors) {
			//if we find a node that has been started but not finished,
			//then we have a cycle and cannot do a topological sort
			if(started.contains(neighbor) && !finished.contains(neighbor)) {
				return false;
			}
			
			//if the neighbor hasn't been started, we should start them!
			if(!started.contains(neighbor)) {
				//YOUR CODE HERE: visit the neighbor and return false if there was a cycle detected
				//on that visit
			}
			
		}
		
		//YOUR CODE HERE: This node is "finished" so add it to the finished set
		
		//YOUR CODE HERE: Push this node onto our state (the front of the LinkedList
		//called "sortedOrder"
		
		return true; //leave this, it means no loop was detected
	}
}